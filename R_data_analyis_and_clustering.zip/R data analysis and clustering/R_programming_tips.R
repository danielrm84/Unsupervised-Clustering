###################################################
#
#	BASICS OF PROGRAMMING USING R
#
###################################################

	- comments: the sharp/hashtag/number sign sybol #
	- print() function, useful for debugging
	- data types
	- operators
	- if-else conditional statements
	- for-loops
	- functions

# working the data
	- reading csv
	- the $ symbol
	- selecting columns and rows
	- computing mean, std, median
	- simple correlation plots

# install packages for next step!

# REQUIRED LIBRARIES
 install.packages("stats") # kmeans model
 install.packages("cluster") # silhouette coefficient function
 install.packages("ggplot2")
 install.packages("FactoMineR")
 install.packages("factoextra")
 install.packages("rgl") # 3d plots
 install.packages("BBmisc")# normalize() function
 install.packages("e1071") # sigmoid function
 install.packages("car") # scatter3d plot


ggscatter(df, x = "bandwidth", y = "freq_sd"
		 ,add = "reg.line" # add a linear regression line
		 ,conf.int = TRUE  # add confidence interval
		 ,conf.int.level = 0.95 # confidence level
		 ,cor.coef = TRUE  # correlation coefficient and p-value
		 ,cor.method = "pearson" # "pearson", "kendall", or "spearman"
		)