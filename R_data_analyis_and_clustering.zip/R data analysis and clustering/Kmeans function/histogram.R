
### PLOT HISTOGRAMS TO COMPARE CLUSTERS WITH AGE CLASSES

# read data
#df <- read.csv("etary_groups.csv", sep = ";", header = TRUE)

# backup dataframe
myData <- df

# prepare data
df <- df[,-c(1:7)]

# run kmeans model
km <- KmeansElbow(df
			,rep = 500
			,max.clusters = 100
			,nstars = 100
			,scaling.method = "standardization"
			,decision.method = "knee"#"sillhouette"
			)

cluster <- myData$Label
#cluster <- km$cluster

#y <- cbind(cluster,myData)

condition <- (y$Ruftyp..Alexandra. == "Trill" |
		  y$Ruftyp..Alexandra. == "Prototrill") #&
		 #y$ID == "j17-18"

#cluster <- y$cluster[condition]
cluster <- y$Label[condition]

class   <- as.factor(myData$ID)
class <- myData$ID[condition] # if it is already a factor

#histograms
par(mfrow=c(1,3))
for (i in c(levels(class)))
{
	x = cluster[class == i]
	h = hist(x, plot = FALSE
		   , breaks = seq(0,length(levels(as.factor(cluster))))) 
	h$density = h$counts/sum(h$counts)*100
	plot(h,freq=FALSE, col = "grey", las = 1
	, main = bquote("sp = " ~ .(i))
	#, h$breaks = 3
	, ylim = c(0, 100)
	#, xlim = c(0,5)
	#,xaxt = "n"
	)

	## add x axis
	#axis(1, at = c(0.5, 1.5, 2.5), labels = levels(as.factor(cluster)))
}

myData$Ruftyp..Alexandra.[#condition &
				  cluster == 7 &
				  myData$ID == "j10-11"]